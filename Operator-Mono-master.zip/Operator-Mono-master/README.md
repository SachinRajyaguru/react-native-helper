
# Operator-Mono Font

A nice code font

## Usage

```sh
$ git clone https://github.com/tita0x00/Operator-Mono.git
```




